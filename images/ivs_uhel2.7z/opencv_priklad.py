import cv2

img = cv2.imread("nao.jpg")

cv2.imshow("img", img)
cv2.waitKey(-1)

